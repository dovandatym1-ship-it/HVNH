// Build báo cáo bài tập lớn - HTTT Quản lý nâng cao
// Output: BaiTapLon_HTTTQL_VNPT.docx

const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun,
  Header, Footer, AlignmentType, PageOrientation, LevelFormat, ExternalHyperlink,
  TableOfContents, HeadingLevel, BorderStyle, WidthType, ShadingType,
  VerticalAlign, PageNumber, PageBreak, TabStopType, TabStopPosition
} = require('docx');

const ASSETS = path.join(__dirname, 'assets');

// ============== HELPERS ==============
const FONT = "Times New Roman";

function P(text, opts = {}) {
  const { bold = false, italic = false, size = 26, align = AlignmentType.JUSTIFIED, spacing = { line: 360, after: 120 }, indent = { firstLine: 720 } } = opts;
  return new Paragraph({
    alignment: align,
    spacing: spacing,
    indent: opts.indent === false ? undefined : indent,
    children: [new TextRun({ text, bold, italics: italic, size, font: FONT })]
  });
}

function H1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    alignment: AlignmentType.LEFT,
    spacing: { before: 360, after: 200 },
    children: [new TextRun({ text, bold: true, size: 32, font: FONT, color: "1F4E79" })]
  });
}

function H2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    alignment: AlignmentType.LEFT,
    spacing: { before: 240, after: 160 },
    children: [new TextRun({ text, bold: true, size: 28, font: FONT, color: "2E75B6" })]
  });
}

function H3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    alignment: AlignmentType.LEFT,
    spacing: { before: 200, after: 120 },
    children: [new TextRun({ text, bold: true, italics: true, size: 26, font: FONT, color: "404040" })]
  });
}

function CENTER(text, opts = {}) {
  const { bold = false, size = 26, color = "000000", italic = false } = opts;
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { line: 360, after: 80, ...(opts.spacing || {}) },
    children: [new TextRun({ text, bold, italics: italic, size, font: FONT, color })]
  });
}

function BULLET(text) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 320, after: 80 },
    children: [new TextRun({ text, size: 26, font: FONT })]
  });
}

function BULLET_MIX(parts) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 320, after: 80 },
    children: parts.map(p => new TextRun({ text: p.text, size: 26, font: FONT, bold: !!p.bold, italics: !!p.italic }))
  });
}

function IMG(file, w, h, caption) {
  const data = fs.readFileSync(path.join(ASSETS, file));
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 240, after: 80 },
      children: [new ImageRun({
        type: "png",
        data,
        transformation: { width: w, height: h },
        altText: { title: caption, description: caption, name: file }
      })]
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 240 },
      children: [new TextRun({ text: caption, italics: true, size: 22, font: FONT, color: "595959" })]
    })
  ];
}

// ============== TABLE HELPERS ==============
const tableBorder = { style: BorderStyle.SINGLE, size: 6, color: "808080" };
const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };

function TCell(text, opts = {}) {
  const { bold = false, fill = null, width = 1800, align = AlignmentType.LEFT, size = 22 } = opts;
  const cellOpts = {
    borders: cellBorders,
    width: { size: width, type: WidthType.DXA },
    margins: { top: 80, bottom: 80, left: 100, right: 100 },
    verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({
      alignment: align,
      spacing: { line: 280 },
      children: [new TextRun({ text, bold, size, font: FONT })]
    })]
  };
  if (fill) cellOpts.shading = { fill, type: ShadingType.CLEAR };
  return new TableCell(cellOpts);
}

// ============== CONTENT ==============

const coverPage = [
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: "HỌC VIỆN NGÂN HÀNG", bold: true, size: 28, font: FONT })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: "KHOA CÔNG NGHỆ THÔNG TIN & KINH TẾ SỐ", bold: true, size: 26, font: FONT })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 600 }, children: [new TextRun({ text: "------------- o0o -------------", size: 26, font: FONT })] }),

  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 240 }, children: [new TextRun({ text: "BÀI TẬP LỚN KẾT THÚC HỌC PHẦN", bold: true, size: 36, font: FONT, color: "1F4E79" })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({ text: "Môn học: HỆ THỐNG THÔNG TIN QUẢN LÝ NÂNG CAO", bold: true, size: 28, font: FONT })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 600 }, children: [new TextRun({ text: "(Chương trình Thạc sĩ ngành Hệ thống thông tin quản lý)", italics: true, size: 24, font: FONT })] }),

  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 240 }, children: [new TextRun({ text: "ĐỀ TÀI", bold: true, size: 28, font: FONT })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({ text: "KIẾN TRÚC HỆ THỐNG THÔNG TIN VÀ ĐỀ XUẤT ỨNG DỤNG", bold: true, size: 30, font: FONT, color: "C00000" })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({ text: "GENERATIVE AI ĐỂ CẢI TIẾN QUY TRÌNH CUNG CẤP", bold: true, size: 30, font: FONT, color: "C00000" })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 600 }, children: [new TextRun({ text: "DỊCH VỤ FTTH TẠI TẬP ĐOÀN VNPT", bold: true, size: 30, font: FONT, color: "C00000" })] }),

  new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 120 }, indent: { left: 2880 }, children: [new TextRun({ text: "Học viên thực hiện: ", bold: true, size: 26, font: FONT }), new TextRun({ text: "Nguyễn Minh Hiếu", size: 26, font: FONT })] }),
  new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 120 }, indent: { left: 2880 }, children: [new TextRun({ text: "Lớp: ", bold: true, size: 26, font: FONT }), new TextRun({ text: "Cao học HTTTQL - K27", size: 26, font: FONT })] }),
  new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 120 }, indent: { left: 2880 }, children: [new TextRun({ text: "Đơn vị công tác: ", bold: true, size: 26, font: FONT }), new TextRun({ text: "VNPT AI Hà Nội", size: 26, font: FONT })] }),
  new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 600 }, indent: { left: 2880 }, children: [new TextRun({ text: "Năm học: ", bold: true, size: 26, font: FONT }), new TextRun({ text: "2025 - 2026", size: 26, font: FONT })] }),

  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: "HÀ NỘI, THÁNG 5 NĂM 2026", bold: true, size: 26, font: FONT })] }),
  new Paragraph({ children: [new PageBreak()] }),
];

// ============== INTRODUCTION ==============
const intro = [
  H1("LỜI MỞ ĐẦU"),
  P("Em xin chân thành cảm ơn thầy/cô đã hướng dẫn học phần Hệ thống thông tin quản lý nâng cao - một học phần mà em thấy thật sự bổ ích cho công việc hằng ngày của mình tại VNPT AI Hà Nội. Bản thân em làm về phân tích nghiệp vụ (Business Analyst) cho một số sản phẩm số của VNPT, nên những kiến thức về kiến trúc doanh nghiệp, mô hình hóa quy trình hay cách nhìn tổng thể về một hệ thống thông tin doanh nghiệp giúp em rất nhiều khi làm việc với khách hàng và đội phát triển."),
  P("Với bài tập lớn này, em quyết định chọn chính nơi mình đang làm việc - Tập đoàn Bưu chính Viễn thông Việt Nam (VNPT) - làm đối tượng nghiên cứu. Lựa chọn này một phần vì em có lợi thế tiếp cận thông tin, một phần vì VNPT là một doanh nghiệp lớn, hệ thống thông tin đồ sộ và đang trong giai đoạn chuyển dịch mạnh mẽ sang doanh nghiệp công nghệ số. Quy trình em chọn để phân tích sâu là quy trình cung cấp dịch vụ Internet cáp quang FTTH cho khách hàng cá nhân - một quy trình \"xương sống\" trong chuỗi giá trị của VNPT, đụng tới hầu hết các hệ thống thông tin chính của Tập đoàn."),
  P("Trong giới hạn 10 điểm, bài làm gồm 5 phần tương ứng 5 câu hỏi của đề. Em cố gắng trình bày đi từ tổng thể đến chi tiết: bắt đầu bằng bức tranh chung về VNPT, sau đó nhìn vào kiến trúc hệ thống thông tin theo khung TOGAF, rồi đi sâu vào một quy trình cụ thể, đánh giá hiện trạng và cuối cùng đề xuất một phương án cải tiến bằng Generative AI - công nghệ mà chính VNPT đang đầu tư rất mạnh thông qua các sản phẩm như VNPT SmartBot, VNPT AMI."),
  P("Vì khuôn khổ bài tập có hạn và một số dữ liệu nội bộ của Tập đoàn không thể công bố, em xin phép sử dụng các nguồn dữ liệu công khai (báo cáo thường niên, website VNPT, các bài báo chính thống) kết hợp với quan sát thực tế khi làm việc tại VNPT. Em rất mong nhận được góp ý của thầy/cô để bài làm hoàn thiện hơn."),
  new Paragraph({ children: [new PageBreak()] }),
];

// ============== CÂU 1 ==============
const cau1 = [
  H1("CÂU 1. GIỚI THIỆU VỀ TẬP ĐOÀN VNPT"),
  H2("1.1. Giới thiệu chung và lịch sử ra đời"),
  P("Tập đoàn Bưu chính Viễn thông Việt Nam, gọi tắt là VNPT (Vietnam Posts and Telecommunications Group), là một trong những trụ cột của ngành viễn thông và công nghệ thông tin Việt Nam. Cái tên VNPT có lẽ quá quen thuộc với bất kỳ người dân nào đã từng dùng điện thoại bàn, MyTV hay đăng ký mạng cáp quang ở Việt Nam trong vài chục năm gần đây."),
  P("VNPT chính thức được thành lập theo Quyết định số 06/2006/QĐ-TTg ngày 09/01/2006 của Thủ tướng Chính phủ, trên cơ sở tổ chức lại Tổng công ty Bưu chính Viễn thông Việt Nam (vốn có lịch sử gắn liền với ngành Bưu điện từ năm 1945). Trụ sở chính của Tập đoàn đặt tại Tòa nhà VNPT, số 57 Huỳnh Thúc Kháng, Đống Đa, Hà Nội. Khách hàng có thể tìm hiểu dịch vụ trực tiếp tại website vnpt.com.vn, vnpt.vn hoặc gọi tổng đài chăm sóc khách hàng 18001166 - một con số rất nhiều người Việt thuộc lòng."),
  P("Theo Quyết định 1019/QĐ-TTg ngày 23/9/2024 của Thủ tướng Chính phủ phê duyệt Chiến lược phát triển VNPT đến năm 2030, tầm nhìn 2035, Tập đoàn được định hướng chuyển đổi thành công từ doanh nghiệp viễn thông truyền thống sang doanh nghiệp công nghệ số, làm chủ một số nền tảng quan trọng để dẫn dắt chuyển đổi số quốc gia. Đây là một định hướng có tính lịch sử, đặt nền cho việc tổ chức lại bộ máy và đầu tư công nghệ những năm gần đây."),

  H2("1.2. Sản phẩm và dịch vụ chính"),
  P("Là một tập đoàn viễn thông - công nghệ tổng hợp, danh mục sản phẩm dịch vụ của VNPT khá rộng. Em xin nhóm thành bốn cụm chính cho dễ hình dung:"),
  BULLET_MIX([{ text: "Dịch vụ viễn thông cho khách hàng cá nhân (B2C): ", bold: true }, { text: "thuê bao di động VinaPhone (đã phủ sóng 5G trên 63 tỉnh thành kể từ năm 2024), Internet cáp quang FTTH (thương hiệu FiberVNN, gói Home cho hộ gia đình), truyền hình MyTV và VNPT Smart Home." }]),
  BULLET_MIX([{ text: "Dịch vụ cho doanh nghiệp (B2B): ", bold: true }, { text: "đường truyền MetroNet, MegaWAN, dịch vụ kết nối liên tỉnh - quốc tế, dịch vụ trung tâm dữ liệu VNPT IDC, dịch vụ điện toán đám mây VNPT Smart Cloud, các giải pháp an toàn thông tin của VNPT-Cyber Immunity." }]),
  BULLET_MIX([{ text: "Dịch vụ số và nền tảng công nghệ: ", bold: true }, { text: "trợ lý ảo VNPT SmartBot và AMI, nền tảng AI vnptai.io, giải pháp eKYC, hệ sinh thái thanh toán VNPT Money/VNPT Pay, hệ thống VNPT iOffice cho khối hành chính." }]),
  BULLET_MIX([{ text: "Dịch vụ phục vụ Chính phủ điện tử: ", bold: true }, { text: "VNPT là đơn vị triển khai hạ tầng cho nhiều dự án quan trọng như Trục liên thông văn bản quốc gia, Cổng dịch vụ công, Cơ sở dữ liệu quốc gia về dân cư, hệ thống định danh điện tử quốc gia." }]),

  H2("1.3. Bối cảnh thị trường và tình hình sản xuất kinh doanh"),
  P("Thị trường viễn thông Việt Nam hiện do ba \"ông lớn\" thống trị: Viettel, VNPT và MobiFone. Sau giai đoạn tăng trưởng nóng của di động, từ năm 2020 trở lại đây thị trường viễn thông truyền thống dần bão hòa, ARPU di động giảm và áp lực cạnh tranh ngày càng gắt gao. Trong khi đó, các dịch vụ số (Cloud, AI, eKYC, thanh toán số…) lại đang là khoảng trống lớn để khai phá. Năm 2024 còn có thêm một số yếu tố làm khó nhà mạng như: quy định dừng phát triển SIM mới qua đại lý, chi tiêu công cho chuyển đổi số chậm lại, và làn sóng OTT thay thế dịch vụ viễn thông truyền thống."),
  P("Trong bối cảnh đó, VNPT vẫn duy trì được tăng trưởng. Theo công bố tại Hội nghị tổng kết năm 2024, tổng doanh thu toàn Tập đoàn ước đạt 58.540 tỷ đồng, hoàn thành kế hoạch và tăng khoảng 7% so với năm trước. Lợi nhuận trước thuế hợp nhất đạt 6.086 tỷ đồng, riêng Công ty mẹ là 4.565 tỷ đồng (đạt 103,3% kế hoạch). Một con số rất đáng chú ý là tỷ suất lợi nhuận trên vốn chủ sở hữu của Công ty mẹ tăng 29,5% so với kế hoạch - cho thấy hiệu quả sử dụng vốn đã được cải thiện rõ rệt."),
  P("Cũng trong năm 2024, VNPT đưa mạng 5G VinaPhone thương mại hóa rộng rãi, đồng thời mở rộng hệ sinh thái Smart Home (camera AI, Smart WiFi, MyTV…). Bước sang 2025, Chính phủ ban hành Nghị quyết 186/NQ-CP ngày 25/6/2025 phê duyệt chủ trương sáp nhập VNPT-VinaPhone và VNPT-Media vào Công ty mẹ Tập đoàn, theo mô hình \"Lõi hợp nhất\" - đây là một thay đổi tổ chức rất lớn nhằm tinh gọn bộ máy và rút ngắn ra quyết định."),

  H2("1.4. Cơ cấu tổ chức"),
  P("Sau giai đoạn tái cơ cấu 2014 - 2015, mô hình VNPT được chia thành \"3 lớp\": (i) hạ tầng mạng - do VNPT-Net đảm trách, (ii) kinh doanh dịch vụ - do VNPT-VinaPhone đảm trách, (iii) giá trị gia tăng và nội dung số - do VNPT-Media đảm trách. Bên cạnh đó còn có VNPT-IT (thành lập 2018) chuyên phát triển phần mềm và VNPT-Technology chuyên về thiết bị, phần cứng. Mạng lưới hiện diện trên cả nước thông qua 63 chi nhánh tỉnh/thành (gọi là VNPT các tỉnh)."),
  P("Từ tháng 6/2025, theo chủ trương mới, VNPT-VinaPhone và VNPT-Media được sáp nhập trở lại vào Công ty mẹ; mô hình mới sẽ tổ chức theo trục dọc nghiệp vụ (mobile, broadband, digital service, B2B…) thay vì trục công ty con. Mục tiêu là đến hết năm 2025 tổng doanh thu toàn Tập đoàn đạt trên 287 nghìn tỷ đồng cho cả giai đoạn 2021 - 2025 và VNPT trở thành tập đoàn công nghệ chứ không còn thuần túy là nhà mạng nữa."),

  H2("1.5. Chiến lược cạnh tranh và chuỗi giá trị"),
  P("Theo khung phân tích của M. Porter, ba chiến lược cạnh tranh phổ biến gồm dẫn đầu chi phí, khác biệt hóa và tập trung. Qua quan sát thực tế và đối chiếu với Chiến lược phát triển VNPT đến 2030, em cho rằng VNPT đang theo đuổi chiến lược kết hợp giữa khác biệt hóa và tập trung trọng tâm vào phân khúc khách hàng có giá trị cao. Cụ thể, VNPT không chạy đua giá rẻ với các nhà mạng giá thấp, mà nhấn mạnh ba điểm khác biệt: (1) chất lượng hạ tầng mạng quốc gia (cáp quang biển, IP-MPLS backbone, IDC tier III/IV), (2) hệ sinh thái dịch vụ số đồng bộ với chính phủ điện tử và doanh nghiệp lớn, (3) năng lực \"Make in Vietnam\" với các sản phẩm AI - Big Data tự phát triển."),
  P("Để thực thi được chiến lược đó, chuỗi giá trị của VNPT (theo mô hình Porter) có thể nhìn thành các hoạt động chính và hỗ trợ sau. Bảng dưới đây em tổng hợp lại cho dễ tra cứu:"),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2200, 7160],
    rows: [
      new TableRow({ tableHeader: true, children: [
        TCell("Hoạt động trong chuỗi giá trị", { bold: true, fill: "1F4E79", width: 2200, size: 22 }),
        TCell("Vai trò trong việc thực thi chiến lược cạnh tranh của VNPT", { bold: true, fill: "1F4E79", width: 7160, size: 22 })
      ]}),
      new TableRow({ children: [
        TCell("Hậu cần đầu vào", { bold: true, width: 2200 }),
        TCell("Mua sắm thiết bị mạng (Huawei, Nokia, ZTE…), thuê dung lượng quốc tế, hợp tác với các đối tác hạ tầng. VNPT-Technology còn tự sản xuất một phần thiết bị đầu cuối (modem GPON, set-top-box MyTV) để chủ động và giảm phụ thuộc nhập khẩu.", { width: 7160 })
      ]}),
      new TableRow({ children: [
        TCell("Vận hành", { bold: true, fill: "F2F2F2", width: 2200 }),
        TCell("Vận hành mạng truy nhập di động VinaPhone 4G/5G, mạng cáp quang FTTH, mạng truyền dẫn IP-MPLS, các trung tâm dữ liệu VNPT IDC. Đây là \"trái tim\" tạo ra dịch vụ và quyết định trải nghiệm khách hàng.", { width: 7160, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("Hậu cần đầu ra", { bold: true, width: 2200 }),
        TCell("Phân phối dịch vụ thông qua 63 chi nhánh VNPT tỉnh, hệ thống điểm giao dịch, đại lý, kênh online (website, My VNPT app), tổng đài 18001166 và các đội kỹ thuật triển khai tại nhà khách hàng.", { width: 7160 })
      ]}),
      new TableRow({ children: [
        TCell("Marketing & bán hàng", { bold: true, fill: "F2F2F2", width: 2200 }),
        TCell("Truyền thông thương hiệu VinaPhone, FiberVNN, MyTV; chương trình khuyến mại, combo dịch vụ Home Combo; bán hàng B2B cho khối doanh nghiệp và chính phủ.", { width: 7160, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("Dịch vụ sau bán", { bold: true, width: 2200 }),
        TCell("Tổng đài 18001166, chatbot SmartBot, đội kỹ thuật xử lý sự cố tại địa bàn, ứng dụng My VNPT cho tra cứu và thanh toán.", { width: 7160 })
      ]}),
      new TableRow({ children: [
        TCell("Hoạt động hỗ trợ", { bold: true, fill: "FFF2CC", width: 2200 }),
        TCell("Hạ tầng quản trị (tài chính, kế toán, ERP), quản trị nhân lực (HRM), nghiên cứu phát triển (VNPT-IT, VNPT AI, VNPT Technology), mua sắm tập trung và an toàn thông tin (VNPT-Cyber Immunity).", { width: 7160, fill: "FFF2CC" })
      ]})
    ]
  }),
  P("Có thể thấy trong chuỗi giá trị này, hệ thống thông tin chính là \"mạch máu\" nối các hoạt động lại với nhau. Một CRM không tốt sẽ kéo cả khâu CSKH đi xuống; một OSS yếu kém sẽ làm chậm việc cung cấp dịch vụ; còn một hệ thống BI nghèo nàn sẽ khiến lãnh đạo ra quyết định trong điều kiện thiếu thông tin. Đây cũng là lý do tại sao việc nhìn lại kiến trúc hệ thống thông tin (Câu 2) lại quan trọng đến vậy."),

  new Paragraph({ children: [new PageBreak()] }),
];

// ============== CÂU 2 ==============
const cau2 = [
  H1("CÂU 2. KIẾN TRÚC HỆ THỐNG THÔNG TIN CỦA VNPT THEO KHUNG TOGAF"),
  H2("2.1. Vì sao em chọn khung TOGAF"),
  P("Trong các khung kiến trúc doanh nghiệp phổ biến (Zachman, TOGAF, FEAF, Gartner), TOGAF (The Open Group Architecture Framework) là một trong những khung đầy đủ và được áp dụng rộng rãi nhất. Điểm em thấy hữu ích nhất khi đặt VNPT vào TOGAF là cách khung này chia kiến trúc doanh nghiệp thành 4 tầng rất rõ ràng: tầng nghiệp vụ (Business Architecture), tầng ứng dụng (Application Architecture), tầng dữ liệu (Data Architecture) và tầng công nghệ (Technology Architecture)."),
  P("Cách chia này rất tự nhiên với một tập đoàn viễn thông cỡ VNPT - nơi mà người làm nghiệp vụ, người làm ứng dụng (software), người quản trị dữ liệu và đội vận hành hạ tầng mạng thường là những team khác nhau, đôi khi nói \"khác ngôn ngữ\" với nhau. Đặt 4 tầng cạnh nhau giúp ta nhìn thấy bức tranh tổng thể và hiểu vì sao thay đổi ở một tầng thường kéo theo thay đổi ở các tầng khác."),

  H2("2.2. Sơ đồ kiến trúc tổng thể"),
  P("Em đã tổng hợp các hệ thống thông tin chính của VNPT thành sơ đồ kiến trúc 4 tầng sau (vẽ bằng SVG, in lại ở dạng hình ảnh để dễ trình bày trong báo cáo):"),
  ...IMG("togaf.png", 620, 442, "Hình 2.1. Kiến trúc doanh nghiệp VNPT theo khung TOGAF - 4 tầng kiến trúc"),

  H2("2.3. Mô tả chi tiết từng tầng kiến trúc"),
  H3("2.3.1. Tầng nghiệp vụ (Business Layer)"),
  P("Tầng này mô tả các nhóm hoạt động nghiệp vụ - cái mà người làm BA như em thường gọi là \"value streams\" hoặc \"business capabilities\". Với VNPT, em nhận diện sáu nhóm nghiệp vụ lõi:"),
  BULLET("Bán hàng & chăm sóc khách hàng: tư vấn gói cước, tiếp nhận yêu cầu lắp đặt mới/nâng cấp, xử lý khiếu nại và CSKH định kỳ."),
  BULLET("Cung cấp dịch vụ (Service Provisioning): khảo sát hạ tầng, lắp đặt, kích hoạt dịch vụ tại nhà khách hàng - đây là khâu em phân tích kỹ ở Câu 3."),
  BULLET("Vận hành mạng lưới: giám sát chất lượng mạng 24/7, phát hiện và xử lý sự cố, bảo dưỡng định kỳ - vốn là phần \"khó nhìn\" nhưng quyết định trải nghiệm khách hàng."),
  BULLET("Tính cước và thu cước: ghi nhận CDR, áp giá, phát hành hóa đơn, thu nợ - liên quan trực tiếp tới dòng tiền của Tập đoàn."),
  BULLET("Tài chính - kế toán: sổ cái, quản lý doanh thu - chi phí, lập báo cáo tài chính theo chuẩn VAS/IFRS, quản lý tài sản và đầu tư."),
  BULLET("Quản trị nhân sự và hành chính: tuyển dụng, đào tạo, KPI, quản lý văn bản nội bộ, điều hành hành chính."),

  H3("2.3.2. Tầng ứng dụng (Application Layer)"),
  P("Tầng ứng dụng chính là tập hợp các phần mềm/HTTT được triển khai để \"hiện thực hóa\" các hoạt động nghiệp vụ ở trên. Ở VNPT, em quan sát thấy có chừng 12 hệ thống lõi tương ứng. Bảng sau tóm tắt các hệ thống chính kèm chức năng:"),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1300, 2200, 5860],
    rows: [
      new TableRow({ tableHeader: true, children: [
        TCell("Nhóm", { bold: true, fill: "70AD47", width: 1300, size: 22, align: AlignmentType.CENTER }),
        TCell("Tên hệ thống", { bold: true, fill: "70AD47", width: 2200, size: 22 }),
        TCell("Chức năng chính", { bold: true, fill: "70AD47", width: 5860, size: 22 })
      ]}),
      new TableRow({ children: [
        TCell("Khách hàng", { bold: true, width: 1300 }),
        TCell("CRM (Customer Relationship Mgmt)", { bold: true, width: 2200 }),
        TCell("Quản lý hồ sơ khách hàng (cá nhân, doanh nghiệp), lead, cơ hội bán hàng, ticket chăm sóc, lịch sử tương tác đa kênh.", { width: 5860 })
      ]}),
      new TableRow({ children: [
        TCell("Khách hàng", { bold: true, fill: "F2F2F2", width: 1300 }),
        TCell("My VNPT App / Portal khách hàng", { bold: true, fill: "F2F2F2", width: 2200 }),
        TCell("Kênh giao dịch số tự phục vụ (self-service): tra cứu cước, đăng ký gói mới, báo hỏng, thanh toán.", { width: 5860, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("Bán hàng", { bold: true, width: 1300 }),
        TCell("BSS (Business Support Systems)", { bold: true, width: 2200 }),
        TCell("Order Management (quản lý đơn hàng), Product Catalog (catalog sản phẩm - gói cước), Pricing & Rating, Billing - phát hành hóa đơn và quản lý cước.", { width: 5860 })
      ]}),
      new TableRow({ children: [
        TCell("Mạng lưới", { bold: true, fill: "F2F2F2", width: 1300 }),
        TCell("OSS - Service Fulfillment", { bold: true, fill: "F2F2F2", width: 2200 }),
        TCell("Tự động hóa việc cung cấp dịch vụ: nhận work order từ BSS, gọi xuống thiết bị (OLT, BRAS, IMS…) để cấu hình, kích hoạt thuê bao.", { width: 5860, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("Mạng lưới", { bold: true, width: 1300 }),
        TCell("OSS - NMS / Service Assurance", { bold: true, width: 2200 }),
        TCell("Network Management System: giám sát thiết bị, cảnh báo sự cố, đo chất lượng dịch vụ (KPI), điều phối xử lý lỗi.", { width: 5860 })
      ]}),
      new TableRow({ children: [
        TCell("Mạng lưới", { bold: true, fill: "F2F2F2", width: 1300 }),
        TCell("Network Inventory", { bold: true, fill: "F2F2F2", width: 2200 }),
        TCell("Quản lý tài nguyên mạng vật lý và logic: OLT - ODF - splitter - port, dải IP, VLAN, vùng phục vụ, bản đồ cáp GIS.", { width: 5860, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("Quản trị", { bold: true, width: 1300 }),
        TCell("ERP (Oracle / SAP)", { bold: true, width: 2200 }),
        TCell("Tài chính - kế toán, mua sắm, quản lý tài sản cố định, quản lý dự án đầu tư.", { width: 5860 })
      ]}),
      new TableRow({ children: [
        TCell("Quản trị", { bold: true, fill: "F2F2F2", width: 1300 }),
        TCell("HRM", { bold: true, fill: "F2F2F2", width: 2200 }),
        TCell("Quản lý nhân sự, chấm công, tính lương, KPI, đào tạo, lộ trình thăng tiến.", { width: 5860, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("Quản trị", { bold: true, width: 1300 }),
        TCell("VNPT iOffice (EDMS)", { bold: true, width: 2200 }),
        TCell("Hệ thống quản lý văn bản và điều hành nội bộ; đã tích hợp AI/Chatbot để hỗ trợ tra cứu, soạn thảo công văn.", { width: 5860 })
      ]}),
      new TableRow({ children: [
        TCell("Phân tích", { bold: true, fill: "F2F2F2", width: 1300 }),
        TCell("DWH & BI", { bold: true, fill: "F2F2F2", width: 2200 }),
        TCell("Data Warehouse hợp nhất dữ liệu các hệ thống nguồn (CRM, BSS, OSS), Business Intelligence cho lãnh đạo và phân tích kinh doanh.", { width: 5860, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("AI", { bold: true, width: 1300 }),
        TCell("VNPT SmartBot / AMI", { bold: true, width: 2200 }),
        TCell("Nền tảng chatbot - voicebot - callbot dựa trên NLP, OCR và Generative AI; CSKH tự động đa kênh (Web, Zalo, Facebook, Viber, tổng đài).", { width: 5860 })
      ]}),
      new TableRow({ children: [
        TCell("Thanh toán", { bold: true, fill: "F2F2F2", width: 1300 }),
        TCell("VNPT Money / VNPT Pay", { bold: true, fill: "F2F2F2", width: 2200 }),
        TCell("Cổng thanh toán điện tử và ví VNPT Money - kênh thu cước viễn thông và thanh toán dịch vụ số.", { width: 5860, fill: "F2F2F2" })
      ]})
    ]
  }),

  H3("2.3.3. Tầng dữ liệu (Data Layer)"),
  P("Một đặc thù của doanh nghiệp viễn thông là khối lượng dữ liệu cực lớn - vài tỷ bản ghi CDR mỗi ngày, hàng chục triệu hồ sơ thuê bao, log thiết bị mạng phát sinh liên tục. VNPT tổ chức dữ liệu thành các kho chính sau:"),
  BULLET_MIX([{ text: "Master Customer Data: ", bold: true }, { text: "kho dữ liệu khách hàng tập trung (single customer view), giúp các kênh tiếp xúc khác nhau cùng nhìn một khách hàng theo một định danh duy nhất." }]),
  BULLET_MIX([{ text: "Product / Service Catalog: ", bold: true }, { text: "danh mục các gói cước, dịch vụ, combo - là \"nguồn sự thật\" cho cả BSS, kênh bán và website." }]),
  BULLET_MIX([{ text: "Network Inventory DB: ", bold: true }, { text: "dữ liệu hạ tầng mạng vật lý và logic, kèm thông tin GIS - phục vụ trực tiếp khâu khảo sát và cung cấp dịch vụ." }]),
  BULLET_MIX([{ text: "Billing & Revenue DB: ", bold: true }, { text: "CDR, cước phát sinh, hóa đơn, công nợ, lịch sử thanh toán - dữ liệu nhạy cảm cao và bị giám sát chặt bởi pháp luật về kế toán - thuế." }]),
  BULLET_MIX([{ text: "Data Lake / DWH: ", bold: true }, { text: "kho dữ liệu phân tích, gom dữ liệu từ tất cả các nguồn nói trên cộng với log thiết bị mạng, hành vi sử dụng app, mạng xã hội… - đây là \"mỏ vàng\" để VNPT huấn luyện các mô hình AI." }]),

  H3("2.3.4. Tầng công nghệ (Technology Layer)"),
  P("Tầng này chính là phần cơ sở hạ tầng - thứ mà bản thân VNPT có lợi thế lớn so với rất nhiều doanh nghiệp khác. Em ghi nhận sáu nhóm chính:"),
  BULLET("Hạ tầng mạng truy nhập: mạng di động VinaPhone 4G/5G phủ 63 tỉnh thành, mạng cáp quang FTTH GPON/XGS-PON, mạng cố định băng rộng FiberVNN, mạng IoT NB-IoT."),
  BULLET("Mạng truyền dẫn: trục backbone IP/MPLS Bắc - Nam, DWDM dung lượng lớn, các tuyến cáp quang biển AAG, SMW3, APG, AAE-1 mà VNPT tham gia đầu tư."),
  BULLET("Trung tâm dữ liệu: tổ hợp 8 IDC tiêu chuẩn quốc tế (Tier III/IV), trong đó hai trung tâm lớn nhất ở Hòa Lạc (Hà Nội) và Tân Thuận (TP.HCM)."),
  BULLET("Nền tảng đám mây VNPT Smart Cloud: cung cấp IaaS - PaaS - SaaS, hỗ trợ Kubernetes, AI Platform với GPU dành cho huấn luyện mô hình ML/GenAI."),
  BULLET("An toàn thông tin: Trung tâm SOC VNPT-Cyber Immunity, hệ thống SIEM, IDS/IPS, dịch vụ chống DDoS, hạ tầng PKI và chữ ký số."),
  BULLET("Tích hợp và API: ESB / API Gateway nội bộ, Message Bus (Kafka) cho luồng sự kiện thời gian thực, hệ thống LDAP / SSO dùng chung cho toàn Tập đoàn."),
  P("Nhìn lại bốn tầng, có thể thấy VNPT có một kiến trúc khá đầy đủ và đồng bộ - là tài sản quý hiếm mà không phải doanh nghiệp Việt nào cũng có. Tuy nhiên, sự đầy đủ này cũng đi kèm thách thức: 63 tỉnh, mỗi tỉnh đôi khi triển khai \"phiên bản con\" của hệ thống lõi, dẫn tới phân mảnh dữ liệu và khó vận hành nhất quán. Đây cũng là lý do em chọn đi sâu vào một quy trình cụ thể ở Câu 3 để nhìn các hệ thống \"vận động\" thực sự."),

  new Paragraph({ children: [new PageBreak()] }),
];

// ============== CÂU 3 ==============
const cau3 = [
  H1("CÂU 3. QUY TRÌNH LÕI: CUNG CẤP DỊCH VỤ INTERNET FTTH"),
  H2("3.1. Vì sao em chọn quy trình này"),
  P("Trong rất nhiều quy trình ở VNPT, em chọn quy trình cung cấp dịch vụ Internet cáp quang FTTH cho khách hàng cá nhân (mã sản phẩm FiberVNN Home) với mấy lý do thực tế:"),
  BULLET("Đây là một trong những quy trình tạo doanh thu cố định lớn nhất - thuê bao FTTH có ARPU cao, vòng đời dài và là nền cho các dịch vụ giá trị gia tăng khác như MyTV, Smart Home, VNPT Camera."),
  BULLET("Quy trình đụng vào hầu hết các HTTT lõi: CRM, BSS, OSS Service Fulfillment, OSS NMS, Network Inventory, ERP, DWH - tức là rất giàu \"đất diễn\" để phân tích ở Câu 4 và Câu 5."),
  BULLET("Khâu khảo sát - lắp đặt - kích hoạt là điểm trải nghiệm khách hàng nhạy cảm (thời gian chờ, độ chính xác, sự minh bạch). Nếu cải tiến được, tác động NPS rất rõ - đây cũng là không gian rất tốt để đề xuất AI/RPA ở Câu 5."),

  H2("3.2. Vai trò của quy trình trong chuỗi giá trị VNPT"),
  P("Trong chuỗi giá trị Porter mà em vẽ ở Câu 1, quy trình này nằm gọn ở hai mắt xích \"Hậu cần đầu ra\" và \"Vận hành\" - tức là khâu biến năng lực hạ tầng mạng thành dịch vụ thực tế đến tay khách hàng. Nói cách khác, đây là điểm mà mọi đầu tư mạng lưới, mọi sản phẩm thiết kế bởi marketing đều phải đi qua. Một quy trình tốt sẽ rút ngắn thời gian từ lúc khách hàng có nhu cầu đến lúc dùng được dịch vụ (lead time), tăng tỉ lệ chuyển đổi và giảm chi phí đi lại của đội kỹ thuật."),
  P("Theo cam kết chất lượng (SLA) công bố của VNPT, thời gian lắp đặt từ khi đăng ký đến khi kích hoạt thành công thường là 3-5 ngày làm việc tại khu vực đô thị. Trong thực tế làm BA, em quan sát thấy SLA bị trễ thường rơi vào hai khâu: khảo sát hạ tầng và đợi vật tư - cáp - những điểm rất hợp để đem ra mổ xẻ ở Câu 4."),

  H2("3.3. Mô tả các bước của quy trình hiện tại (As-is)"),
  P("Quy trình As-is gồm 4 giai đoạn chính, tổng cộng 12 hoạt động nghiệp vụ, có sự tham gia của 5 vai trò (khách hàng, CSKH tổng đài, Kinh doanh, Kỹ thuật, Billing/Hậu kiểm). Em mô tả ngắn gọn từng bước:"),

  H3("Giai đoạn 1: Tiếp nhận yêu cầu"),
  BULLET("Bước 1 - Khách hàng phát sinh nhu cầu lắp Internet, liên hệ VNPT qua tổng đài 18001166, website vnpt.com.vn, ứng dụng My VNPT hoặc điểm giao dịch."),
  BULLET("Bước 2 - CSKH tiếp nhận yêu cầu, tạo lead trên CRM, ghi nhận thông tin khách hàng và nhu cầu."),
  BULLET("Bước 3 - CSKH tra cứu vùng phục vụ trên Network Inventory để xem có hạ tầng FTTH ở khu vực đó không. Nếu không có, từ chối yêu cầu (kết thúc bất thành); nếu có, chuyển sang bộ phận Kinh doanh."),

  H3("Giai đoạn 2: Bán hàng và ký hợp đồng"),
  BULLET("Bước 4 - Nhân viên Kinh doanh gọi lại tư vấn gói cước (Home 1, Home 2, Home Combo MyTV…), khuyến mại, cam kết. Gửi báo giá và mẫu hợp đồng."),
  BULLET("Bước 5 - Khách hàng ký hợp đồng giấy (hoặc HĐ điện tử nếu đăng ký online), cung cấp CCCD/Hộ khẩu."),
  BULLET("Bước 6 - Kinh doanh nhập thông tin hợp đồng vào hệ thống BSS, tạo đơn hàng (sales order)."),
  BULLET("Bước 7 - BSS phát hành work order tới Kỹ thuật để khảo sát và lắp đặt."),

  H3("Giai đoạn 3: Khảo sát và lắp đặt"),
  BULLET("Bước 8 - Điều phối kỹ thuật phân công kỹ thuật viên (KTV) theo địa bàn, lên lịch hẹn khách hàng."),
  BULLET("Bước 9 - KTV đến khảo sát thực địa: kiểm tra điểm đấu (ODF/splitter), khoảng cách kéo cáp, mặt bằng lắp ONU. Nếu không khả thi (ví dụ vị trí xa, không còn port trống) thì trả về Kinh doanh để chốt lại với khách hàng."),
  BULLET("Bước 10 - Nếu khả thi, KTV tiến hành kéo cáp, đấu nối ONU và modem WiFi tại nhà khách hàng."),
  BULLET("Bước 11 - KTV cấu hình và kích hoạt dịch vụ qua OSS Service Fulfillment (tạo VLAN, gán port, mở dịch vụ trên BRAS, đẩy cấu hình ACS lên ONU)."),

  H3("Giai đoạn 4: Nghiệm thu và mở cước"),
  BULLET("Bước 12 - Khách hàng kiểm tra tốc độ, ký biên bản nghiệm thu. Hậu kiểm/Billing đóng work order, mở cước trên BSS Billing, phát hành hóa đơn đầu tiên qua VNPT Money/email/SMS. CRM cập nhật trạng thái thuê bao thành \"đang hoạt động\"."),

  H2("3.4. Mô hình hóa BPMN (Bizagi Modeler)"),
  P("Em dùng ký pháp BPMN 2.0 chuẩn để mô hình hóa quy trình trên, có thể export ra file .bpmn của Bizagi Modeler. Trong sơ đồ, em dùng hai pool (VNPT và Khách hàng), bốn lane bên trong pool VNPT (CSKH, Kinh doanh, Kỹ thuật, Billing) cùng các phần tử Task, Gateway XOR, Start/End Event, Sequence flow và Message flow theo đúng BPMN."),
  ...IMG("bpmn_asis.png", 620, 365, "Hình 3.1. Sơ đồ BPMN As-is - Quy trình cung cấp dịch vụ FTTH tại VNPT"),
  P("Một số điểm cần lưu ý trong sơ đồ: (i) gateway XOR đầu tiên ở lane CSKH dùng để xử lý trường hợp không có hạ tầng - nhánh từ chối kết thúc tại End Event \"Từ chối\"; (ii) gateway thứ hai ở lane Kỹ thuật xử lý trường hợp khảo sát không khả thi, quay vòng về Kinh doanh để thương lượng lại với khách hàng; (iii) toàn bộ tương tác với khách hàng được vẽ bằng message flow nét đứt theo chuẩn BPMN."),

  new Paragraph({ children: [new PageBreak()] }),
];

// ============== CÂU 4 ==============
const cau4 = [
  H1("CÂU 4. PHÂN TÍCH HIỆN TRẠNG CÁC HTTT LIÊN QUAN QUY TRÌNH"),
  H2("4.1. Nguyên tắc nhận diện"),
  P("Theo gợi ý của đề bài, quan hệ giữa quy trình nghiệp vụ (BP) và hệ thống thông tin (IS) là quan hệ nhiều - nhiều (N:M). Một BP có thể không cần IS nào, hoặc cần nhiều IS cùng tham gia; ngược lại một IS bắt buộc gắn với ít nhất một BP (vì IS sinh ra để phục vụ nghiệp vụ). Em sẽ trình bày theo hai bước: (i) liệt kê IS có liên quan tới quy trình FTTH, (ii) lập ma trận N:M để nhìn rõ mức độ tham gia."),

  H2("4.2. Danh mục HTTT liên quan và vai trò trong quy trình"),
  P("Em rà soát lại sơ đồ As-is ở Câu 3 và xác định có 8 hệ thống thông tin trực tiếp tham gia quy trình:"),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [800, 2200, 3000, 3360],
    rows: [
      new TableRow({ tableHeader: true, children: [
        TCell("STT", { bold: true, fill: "1F4E79", width: 800, size: 22, align: AlignmentType.CENTER }),
        TCell("Hệ thống (IS)", { bold: true, fill: "1F4E79", width: 2200, size: 22 }),
        TCell("Bước nghiệp vụ tham gia", { bold: true, fill: "1F4E79", width: 3000, size: 22 }),
        TCell("Vai trò trong quy trình", { bold: true, fill: "1F4E79", width: 3360, size: 22 })
      ]}),
      new TableRow({ children: [
        TCell("1", { width: 800, align: AlignmentType.CENTER }),
        TCell("CRM", { bold: true, width: 2200 }),
        TCell("Bước 1, 2, 4, 12", { width: 3000 }),
        TCell("Tiếp nhận yêu cầu, tạo lead, ghi nhận tương tác CSKH, cập nhật trạng thái thuê bao sau lắp.", { width: 3360 })
      ]}),
      new TableRow({ children: [
        TCell("2", { width: 800, align: AlignmentType.CENTER, fill: "F2F2F2" }),
        TCell("Network Inventory", { bold: true, width: 2200, fill: "F2F2F2" }),
        TCell("Bước 3, 9", { width: 3000, fill: "F2F2F2" }),
        TCell("Tra cứu vùng phục vụ, kiểm tra port/ODF còn trống, cấp phát tài nguyên mạng cho thuê bao mới.", { width: 3360, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("3", { width: 800, align: AlignmentType.CENTER }),
        TCell("BSS - Order Management", { bold: true, width: 2200 }),
        TCell("Bước 6, 7, 12", { width: 3000 }),
        TCell("Tạo và quản lý đơn hàng, đẩy work order xuống OSS, ghi nhận trạng thái đơn.", { width: 3360 })
      ]}),
      new TableRow({ children: [
        TCell("4", { width: 800, align: AlignmentType.CENTER, fill: "F2F2F2" }),
        TCell("BSS - Billing & Rating", { bold: true, width: 2200, fill: "F2F2F2" }),
        TCell("Bước 12", { width: 3000, fill: "F2F2F2" }),
        TCell("Mở cước, áp giá gói cước, phát hành hóa đơn đầu tiên, gửi thông báo cước.", { width: 3360, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("5", { width: 800, align: AlignmentType.CENTER }),
        TCell("OSS - Service Fulfillment", { bold: true, width: 2200 }),
        TCell("Bước 7, 11", { width: 3000 }),
        TCell("Tự động cấu hình thiết bị mạng (OLT, BRAS, ACS), kích hoạt dịch vụ trên hạ tầng.", { width: 3360 })
      ]}),
      new TableRow({ children: [
        TCell("6", { width: 800, align: AlignmentType.CENTER, fill: "F2F2F2" }),
        TCell("OSS - NMS/Assurance", { bold: true, width: 2200, fill: "F2F2F2" }),
        TCell("Bước 11, 12", { width: 3000, fill: "F2F2F2" }),
        TCell("Đo chất lượng đường truyền sau lắp, ghi nhận cảnh báo sớm để hỗ trợ nghiệm thu.", { width: 3360, fill: "F2F2F2" })
      ]}),
      new TableRow({ children: [
        TCell("7", { width: 800, align: AlignmentType.CENTER }),
        TCell("My VNPT App / Portal", { bold: true, width: 2200 }),
        TCell("Bước 1, 12", { width: 3000 }),
        TCell("Kênh tự đăng ký dịch vụ và xem tiến độ lắp đặt, kích hoạt eContract.", { width: 3360 })
      ]}),
      new TableRow({ children: [
        TCell("8", { width: 800, align: AlignmentType.CENTER, fill: "F2F2F2" }),
        TCell("VNPT Money / VNPT Pay", { bold: true, width: 2200, fill: "F2F2F2" }),
        TCell("Bước 12", { width: 3000, fill: "F2F2F2" }),
        TCell("Thu cước lắp đặt và phí thuê bao tháng đầu qua kênh số.", { width: 3360, fill: "F2F2F2" })
      ]})
    ]
  }),

  H2("4.3. Ma trận N:M giữa Business Process và Information System"),
  P("Để minh họa rõ quan hệ N:M, em lập ma trận trong đó dòng là các hoạt động (BP1 đến BP12 - tương ứng 12 bước ở Câu 3), cột là 8 hệ thống đã liệt kê. Dấu ✓ ở giao điểm thể hiện IS đó có tham gia vào hoạt động tương ứng:"),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2160, 900, 900, 900, 900, 900, 900, 900, 900],
    rows: [
      new TableRow({ tableHeader: true, children: [
        TCell("Bước", { bold: true, fill: "ED7D31", width: 2160, size: 20, align: AlignmentType.CENTER }),
        TCell("CRM", { bold: true, fill: "ED7D31", width: 900, size: 20, align: AlignmentType.CENTER }),
        TCell("Inv", { bold: true, fill: "ED7D31", width: 900, size: 20, align: AlignmentType.CENTER }),
        TCell("BSS-OM", { bold: true, fill: "ED7D31", width: 900, size: 20, align: AlignmentType.CENTER }),
        TCell("BSS-Bill", { bold: true, fill: "ED7D31", width: 900, size: 20, align: AlignmentType.CENTER }),
        TCell("OSS-SF", { bold: true, fill: "ED7D31", width: 900, size: 20, align: AlignmentType.CENTER }),
        TCell("OSS-NMS", { bold: true, fill: "ED7D31", width: 900, size: 20, align: AlignmentType.CENTER }),
        TCell("MyVNPT", { bold: true, fill: "ED7D31", width: 900, size: 20, align: AlignmentType.CENTER }),
        TCell("VNPT Money", { bold: true, fill: "ED7D31", width: 900, size: 20, align: AlignmentType.CENTER })
      ]}),
      ...[
        ["BP1. Khách phát sinh nhu cầu, liên hệ VNPT", ["", "", "", "", "", "", "✓", ""]],
        ["BP2. CSKH ghi nhận, tạo lead trên CRM", ["✓", "", "", "", "", "", "", ""]],
        ["BP3. Tra cứu vùng phục vụ", ["", "✓", "", "", "", "", "", ""]],
        ["BP4. Tư vấn gói cước, gửi báo giá", ["✓", "", "", "", "", "", "✓", ""]],
        ["BP5. Khách ký HĐ, cung cấp CCCD", ["", "", "", "", "", "", "✓", ""]],
        ["BP6. Tạo đơn hàng trên BSS", ["", "", "✓", "", "", "", "", ""]],
        ["BP7. Phát hành work order", ["", "", "✓", "", "✓", "", "", ""]],
        ["BP8. Điều phối phân công KTV", ["", "✓", "✓", "", "", "", "", ""]],
        ["BP9. Khảo sát thực địa", ["", "✓", "", "", "", "", "", ""]],
        ["BP10. Kéo cáp, đấu nối ONU/modem", ["", "✓", "", "", "", "", "", ""]],
        ["BP11. Cấu hình & kích hoạt qua OSS", ["", "", "", "", "✓", "✓", "", ""]],
        ["BP12. Nghiệm thu, mở cước, xuất hóa đơn", ["✓", "", "✓", "✓", "", "✓", "✓", "✓"]]
      ].map((row, i) => new TableRow({
        children: [
          TCell(row[0], { width: 2160, size: 20, fill: i % 2 === 0 ? null : "FFF2CC" }),
          ...row[1].map(c => TCell(c, { width: 900, size: 22, align: AlignmentType.CENTER, bold: c === "✓", fill: i % 2 === 0 ? null : "FFF2CC" }))
        ]
      }))
    ]
  }),
  P("Đọc ma trận này em rút ra hai quan sát quan trọng:", { indent: false, spacing: { before: 200, line: 360, after: 120 } }),
  BULLET("Một bước nghiệp vụ thường gọi đến nhiều IS cùng lúc (đặc biệt bước 12 - mở cước - đụng đến 6 hệ thống). Đây chính là minh chứng quan hệ N:M."),
  BULLET("Trục \"nóng\" nhất là cụm BSS Order Management - OSS Service Fulfillment - Network Inventory. Nếu ba hệ thống này không nói chuyện được tốt với nhau (ví dụ qua API/ESB), quy trình sẽ tắc nghẽn ngay ở giữa."),

  H2("4.4. Đánh giá hiện trạng - điểm mạnh và điểm yếu"),
  P("Bằng việc kết hợp ma trận trên với quan sát thực tế khi em tham gia một số dự án liên quan, em đưa ra đánh giá hiện trạng các HTTT đang phục vụ quy trình FTTH như sau."),

  H3("Điểm mạnh"),
  BULLET("Bộ HTTT khá đầy đủ, gần như mỗi bước nghiệp vụ đều đã có IS hỗ trợ - đây là tài sản lớn so với nhiều doanh nghiệp Việt cùng quy mô."),
  BULLET("OSS Service Fulfillment đã có khả năng tự động cấu hình thiết bị qua API, nhờ vậy khâu kích hoạt dịch vụ (bước 11) thường chỉ mất vài phút sau khi KTV xác nhận."),
  BULLET("Hệ thống thanh toán VNPT Money/VNPT Pay đã được tích hợp ngay từ bước phát hành hóa đơn đầu tiên - giúp dòng tiền chảy nhanh."),
  BULLET("Bắt đầu có sự hiện diện của AI: VNPT SmartBot đã tham gia trả lời tự động một phần các yêu cầu ở bước 1, dù còn ở mức cơ bản."),

  H3("Điểm yếu và nút thắt"),
  BULLET_MIX([{ text: "Phân mảnh dữ liệu giữa 63 chi nhánh tỉnh: ", bold: true }, { text: "tuy có Master Customer Data, nhưng vẫn còn các phiên bản con của CRM/BSS triển khai ở từng tỉnh. Cùng một khách hàng có thể tồn tại nhiều mã - gây khó khăn cho phân tích và tránh trùng đơn." }]),
  BULLET_MIX([{ text: "Khâu khảo sát (Bước 9) phụ thuộc nặng vào con người: ", bold: true }, { text: "Network Inventory chưa cập nhật thời gian thực, KTV phải đến tận nơi mới biết khả thi hay không. Đây là khâu hay làm chậm SLA 3-5 ngày." }]),
  BULLET_MIX([{ text: "OCR và eKYC chưa được áp dụng triệt để: ", bold: true }, { text: "khách vẫn phải nộp CCCD bản cứng, nhân viên kinh doanh nhập tay vào BSS - dễ sai sót thông tin." }]),
  BULLET_MIX([{ text: "CSKH chủ yếu phản ứng (reactive) chứ chưa chủ động (proactive): ", bold: true }, { text: "OSS NMS có thể phát hiện sự cố trước nhưng dữ liệu chưa được kết nối liền mạch sang CRM/SmartBot để chủ động báo khách hàng." }]),
  BULLET_MIX([{ text: "Bài toán điều phối kỹ thuật (Bước 8) chủ yếu làm theo kinh nghiệm: ", bold: true }, { text: "chưa có thuật toán tối ưu tuyến đường và tải công việc, dẫn tới một số KTV quá tải còn KTV khác lại nhàn." }]),

  H3("Cơ hội cải tiến"),
  P("Tóm lại, các điểm yếu trên đều có một mẫu số chung: chúng là kiểu bài toán mà AI - đặc biệt là Generative AI, ML và RPA - rất phù hợp để xử lý. Đó là tiền đề để em đề xuất phương án cải tiến ở Câu 5."),

  new Paragraph({ children: [new PageBreak()] }),
];

// ============== CÂU 5 ==============
const cau5 = [
  H1("CÂU 5. GIẢI PHÁP CẢI TIẾN BẰNG GENERATIVE AI"),
  H2("5.1. Giới thiệu sơ lược về công nghệ Generative AI"),
  P("Generative AI (AI tạo sinh) là nhánh của trí tuệ nhân tạo dùng các mô hình học sâu - tiêu biểu là Large Language Model (LLM) như GPT, Gemini, Llama hoặc các mô hình tương đương do VNPT đang nghiên cứu - để \"sinh ra\" nội dung mới (văn bản, hình ảnh, mã, dữ liệu cấu trúc) dựa trên dữ liệu được huấn luyện trước đó. Khác với AI truyền thống chủ yếu phân loại hoặc dự đoán, GenAI có thể đối thoại tự nhiên với con người, đọc - hiểu tài liệu phức tạp, viết báo cáo và sinh code."),
  P("Cùng họ với GenAI, em xếp thêm vào đề xuất một vài kỹ thuật AI quen thuộc đã được kiểm chứng trong viễn thông: OCR (nhận dạng văn bản trong ảnh), NLP/NLU (xử lý ngôn ngữ tự nhiên), Recommendation system (hệ gợi ý), Vehicle Routing Problem - ML để tối ưu phân công. Tích hợp với RPA, ta được khái niệm gọi là Intelligent Automation - tự động hóa có trí tuệ."),
  P("VNPT có lợi thế đặc biệt khi nói về AI: bản thân Tập đoàn đã có sản phẩm VNPT SmartBot ứng dụng GenAI + NLP + OCR và đã giành giải Bạc Stevie Awards 2022 ở hạng mục B2B Product. Nền tảng AI vnptai.io đang phục vụ hàng triệu lượt truy vấn mỗi ngày. Có nghĩa là khi em đề xuất giải pháp dưới đây, các thành phần công nghệ phần lớn đã có sẵn nội bộ - chỉ cần lắp ghép và tinh chỉnh."),

  H2("5.2. Vì sao Generative AI phù hợp với quy trình FTTH"),
  P("Em chọn GenAI làm trục cải tiến (thay vì chỉ RPA hay Blockchain) vì ba lý do:"),
  BULLET_MIX([{ text: "Sự đa dạng của tương tác khách hàng: ", bold: true }, { text: "khách hàng có thể chat tự do bằng tiếng Việt, đặt câu hỏi ngữ cảnh phức tạp. GenAI thông qua LLM có khả năng hiểu intent tốt hơn rule-based chatbot truyền thống rất nhiều." }]),
  BULLET_MIX([{ text: "Tính chất bán cấu trúc của hồ sơ: ", bold: true }, { text: "CCCD/Hộ khẩu, mặt bằng nhà, hình ảnh tủ cáp… đều là dữ liệu phi cấu trúc. Tổ hợp OCR + Vision + LLM của GenAI hiện đại xử lý gọn." }]),
  BULLET_MIX([{ text: "Nhu cầu cá nhân hóa: ", bold: true }, { text: "mỗi khách có thói quen dùng Internet khác nhau (gaming, work from home, hộ gia đình đông người…). LLM kết hợp dữ liệu hành vi để gợi ý gói cước phù hợp - đây là điểm khác biệt hóa quan trọng so với đối thủ giá rẻ." }]),

  H2("5.3. Quy trình To-be sau cải tiến"),
  P("Em giữ nguyên khung 4 giai đoạn của quy trình As-is, sau đó chèn thêm các \"AI task\" và \"RPA task\" tại các điểm có thể tự động hóa cao. Sơ đồ BPMN To-be (cũng được vẽ theo chuẩn Bizagi Modeler) như sau:"),
  ...IMG("bpmn_tobe.png", 620, 365, "Hình 5.1. Sơ đồ BPMN To-be - Ứng dụng GenAI và RPA vào quy trình FTTH"),

  H3("Cụ thể các điểm cải tiến (so với As-is)"),
  BULLET_MIX([{ text: "AI-1: GenAI/NLP phân tích intent. ", bold: true }, { text: "Khách hàng chat với VNPT SmartBot trên Zalo/Web/App. LLM hiểu nhu cầu thực sự (lắp mới, đổi gói, báo lỗi…) và tự đặt câu hỏi gợi mở để gom đủ thông tin." }]),
  BULLET_MIX([{ text: "AI-2: OCR + eKYC. ", bold: true }, { text: "Khách chỉ cần chụp CCCD bằng điện thoại, hệ thống OCR trích xuất toàn bộ trường dữ liệu, so khớp gương mặt khách - hoàn tất KYC ngay trong cuộc chat." }]),
  BULLET_MIX([{ text: "AI-3: ML dự đoán khả thi lắp đặt. ", bold: true }, { text: "Mô hình ML nhận dữ liệu Inventory + GIS + lịch sử khảo sát các thuê bao lân cận để chấm điểm khả thi (0-1). Score thấp được từ chối sớm, không cần đợi KTV ra hiện trường - rút ngắn được hàng ngày chờ đợi." }]),
  BULLET_MIX([{ text: "AI-4: Recommendation gói cước. ", bold: true }, { text: "Dựa trên ngữ cảnh hội thoại + dữ liệu thuê bao tương đồng (cùng khu vực, cùng cấu trúc hộ gia đình), LLM gợi ý 2-3 gói cước có xác suất chuyển đổi cao nhất." }]),
  BULLET_MIX([{ text: "AI-5: GenAI sinh hợp đồng điện tử. ", bold: true }, { text: "LLM dựng nội dung hợp đồng theo template, điền sẵn thông tin khách, gửi link ký số. Khách ký xong là dữ liệu đẩy thẳng vào BSS - không còn nhập tay." }]),
  BULLET_MIX([{ text: "AI-6: Tối ưu lịch phân công kỹ thuật viên. ", bold: true }, { text: "Bài toán Vehicle Routing Problem (VRP) kết hợp ML dự đoán thời lượng từng đơn lắp, gom đơn theo cụm địa lý, tối ưu chi phí đi lại và đảm bảo SLA. Một KTV có thể đi nhiều đơn liên tiếp thay vì phân công ngẫu nhiên." }]),
  BULLET_MIX([{ text: "RPA - cấu hình tự động qua OSS API. ", bold: true }, { text: "Bot RPA gọi OSS Service Fulfillment để cấu hình ONU, VLAN, IP - không cần KTV vào lệnh thủ công." }]),
  BULLET_MIX([{ text: "RPA - đóng order, kích cước, xuất hóa đơn điện tử. ", bold: true }, { text: "Sau khi khách xác nhận chất lượng qua App, RPA chạy chuỗi đóng order trên BSS-OM, kích cước trên BSS-Billing, push hóa đơn qua VNPT Money - hết bằng giây thay vì hàng giờ chờ hậu kiểm thủ công." }]),

  H2("5.4. Tính hợp lý của giải pháp"),
  P("Một giải pháp tốt cần đánh giá trên cả góc độ công nghệ, vận hành và kinh doanh. Em đặt ba câu hỏi và trả lời lần lượt:"),

  H3("Công nghệ đã đủ chín muồi chưa?"),
  P("Phần lớn các thành phần em đề xuất đã được VNPT sản xuất và triển khai trong thực tế. VNPT SmartBot đã có sẵn module OCR, NLP, chatbot Generative AI và đã thương mại hóa cho khối doanh nghiệp/chính phủ. ML cho VRP đã được giới học thuật nghiên cứu nhiều năm, có cả thư viện mã nguồn mở (OR-Tools, OptaPlanner). RPA có thể dùng các nền tảng phổ biến (UiPath, akaBot) hoặc tự phát triển. Vì vậy yếu tố \"công nghệ\" không phải rào cản."),

  H3("Có khả thi về vận hành không?"),
  P("Một dự án AI lớn dễ thất bại ở khâu thay đổi vận hành chứ không phải kỹ thuật. Theo em, lộ trình hợp lý là triển khai theo 3 pha:"),
  BULLET_MIX([{ text: "Pha 1 (3-6 tháng): ", bold: true }, { text: "Bật AI-1 (GenAI chatbot tiếp nhận), AI-2 (eKYC), AI-5 (eContract). Đây là các điểm va chạm khách hàng - cải tiến UX ngay, không ảnh hưởng đến đội kỹ thuật." }]),
  BULLET_MIX([{ text: "Pha 2 (6-12 tháng): ", bold: true }, { text: "Bổ sung AI-3 (predict feasibility) và AI-4 (recommendation). Cần thời gian gom dữ liệu, train mô hình, A/B test." }]),
  BULLET_MIX([{ text: "Pha 3 (12-18 tháng): ", bold: true }, { text: "AI-6 (VRP) và bot RPA mở cước/xuất hóa đơn. Pha này đụng tới quy trình vận hành nội bộ và core BSS, cần thay đổi quy chế kỹ thuật và đào tạo lại đội." }]),

  H3("Lợi ích kinh doanh dự kiến"),
  P("Em ước lượng (dựa trên các dự án tương tự ở viễn thông quốc tế và benchmark nội bộ) tác động sau khi triển khai đầy đủ ba pha:"),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3600, 2800, 2960],
    rows: [
      new TableRow({ tableHeader: true, children: [
        TCell("Chỉ tiêu", { bold: true, fill: "70AD47", width: 3600, size: 22 }),
        TCell("Hiện trạng (As-is)", { bold: true, fill: "70AD47", width: 2800, size: 22, align: AlignmentType.CENTER }),
        TCell("Mục tiêu (To-be)", { bold: true, fill: "70AD47", width: 2960, size: 22, align: AlignmentType.CENTER })
      ]}),
      ...[
        ["Thời gian từ đăng ký đến kích hoạt (lead time)", "3 - 5 ngày làm việc", "Trung bình 1 - 2 ngày, đô thị có thể trong ngày"],
        ["Tỉ lệ đơn lắp thành công lần đầu (First Time Right)", "~ 80%", "≥ 92%"],
        ["Tỉ lệ tự phục vụ qua chatbot/app (Self-service)", "~ 25%", "≥ 60%"],
        ["Số đơn KTV xử lý/ngày", "5 - 6 đơn", "8 - 10 đơn nhờ tối ưu lịch"],
        ["Chi phí vận hành CSKH (cost per contact)", "100% baseline", "Giảm 30 - 35% nhờ chatbot và RPA"],
        ["Mức độ hài lòng khách hàng (NPS)", "Trung bình ngành", "Tăng 8 - 12 điểm"]
      ].map((row, i) => new TableRow({
        children: [
          TCell(row[0], { width: 3600, fill: i % 2 === 0 ? null : "F2F2F2" }),
          TCell(row[1], { width: 2800, align: AlignmentType.CENTER, fill: i % 2 === 0 ? null : "F2F2F2" }),
          TCell(row[2], { width: 2960, align: AlignmentType.CENTER, bold: true, fill: i % 2 === 0 ? null : "F2F2F2" })
        ]
      }))
    ]
  }),

  H2("5.5. Một vài rủi ro cần lường trước"),
  P("Để bài không quá lý tưởng hóa, em cũng muốn ghi nhận một số rủi ro thực tế:"),
  BULLET("Rủi ro về dữ liệu cá nhân: GenAI làm việc với CCCD, thông tin liên lạc - cần tuân thủ Nghị định 13/2023/NĐ-CP về bảo vệ dữ liệu cá nhân, có cơ chế anonymization khi train mô hình."),
  BULLET("Rủi ro \"ảo giác\" (hallucination) của LLM: chatbot có thể trả lời sai về gói cước. Phải có guardrail (tìm kiếm dựa trên catalog chính thức - retrieval augmented generation) và human-in-the-loop ở những bước nhạy cảm như báo giá."),
  BULLET("Rủi ro thay đổi tổ chức: việc giảm 30-35% chi phí CSKH có thể đe dọa nhân sự tổng đài hiện hữu. Cần kế hoạch đào tạo lại nhân lực (reskilling) sang vai trò vận hành AI và CSKH cao cấp."),
  BULLET("Rủi ro tích hợp: kết nối với BSS/OSS hiện hữu (vốn là các hệ thống đã chạy nhiều năm) đôi khi tốn công hơn dự kiến - cần phối hợp chặt với VNPT-IT ngay từ đầu."),
  P("Tuy có những rủi ro đó, em vẫn cho rằng đây là hướng đi tất yếu cho VNPT. Bản thân Tập đoàn cũng đã đặt mục tiêu trở thành \"doanh nghiệp công nghệ\" trong chiến lược đến 2030 - và quy trình cung cấp dịch vụ FTTH là một trong những ví dụ rõ nét nhất để chứng minh lợi ích của Generative AI ở quy mô toàn quốc."),

  new Paragraph({ children: [new PageBreak()] }),
];

// ============== CONCLUSION ==============
const conclusion = [
  H1("KẾT LUẬN"),
  P("Qua bài tập này, em đã thử nhìn VNPT - nơi mình đang làm việc - dưới góc độ của một học viên BA, từ tổng thể tới chi tiết. Em rút ra được mấy điều mà em nghĩ là quan trọng cho công việc thực tế của mình ngày mai."),
  P("Đầu tiên là về tư duy hệ thống. Khung TOGAF với bốn tầng kiến trúc giúp mình có một \"bản đồ tổng\" để định vị mọi thay đổi: khi sếp đề nghị thêm một tính năng mới, mình sẽ tự hỏi tính năng đó nằm ở tầng nghiệp vụ nào, đụng vào ứng dụng nào, dữ liệu ra sao và có cần thay đổi hạ tầng không. Câu hỏi đơn giản nhưng giúp tránh được rất nhiều dự án \"chạy mới biết thiếu\"."),
  P("Thứ hai là về sức mạnh của việc mô hình hóa quy trình bằng BPMN. So với việc mô tả bằng văn bản dài dòng, một sơ đồ BPMN As-is buộc người làm BA phải định danh rõ ai làm gì, khi nào, dữ liệu đi qua đâu - những thứ rất hay bị bỏ sót trong tài liệu mô tả. Khi vẽ xong sơ đồ As-is, các \"nút thắt\" gần như tự lộ ra, nhường chỗ cho sơ đồ To-be vốn tự nhiên hơn rất nhiều."),
  P("Thứ ba là về vai trò của Generative AI. Em không nghĩ AI sẽ thay thế hoàn toàn con người trong viễn thông, ít nhất là trong 5-10 năm tới. Nhưng GenAI rõ ràng đang định nghĩa lại cách doanh nghiệp tương tác với khách hàng và vận hành nội bộ. Với VNPT - nơi có sẵn dữ liệu, hạ tầng GPU, sản phẩm SmartBot và nguồn nhân lực kỹ thuật mạnh - thì đây là cơ hội rất hiếm để dẫn đầu thay vì đi sau."),
  P("Em xin được dừng tại đây và một lần nữa cảm ơn thầy/cô đã đọc bài. Em rất mong nhận được nhận xét và gợi ý để hoàn thiện bản thân hơn trong quá trình học và làm việc."),
  new Paragraph({ children: [new PageBreak()] }),
];

// ============== REFERENCES ==============
const refs = [
  H1("TÀI LIỆU THAM KHẢO"),
  P("Trong bài làm, em đã tham khảo các nguồn chính sau:", { indent: false }),
  BULLET("Thủ tướng Chính phủ (2024). Quyết định số 1019/QĐ-TTg ngày 23/9/2024 phê duyệt Chiến lược phát triển VNPT đến năm 2030, tầm nhìn 2035."),
  BULLET("Báo Chính phủ (2024). \"Chiến lược phát triển VNPT đến năm 2030, tầm nhìn đến năm 2035\". baochinhphu.vn"),
  BULLET("VnEconomy (2025). \"Cơ cấu lại Tập đoàn VNPT: Mục tiêu hết 2025, tổng doanh thu đạt hơn 287 nghìn tỷ\". vneconomy.vn"),
  BULLET("VNPT (2024). \"Tập đoàn VNPT năm 2024: Giữ nhịp phát triển trong bối cảnh khó khăn, khai phá không gian tăng trưởng mới\". vnpt.com.vn"),
  BULLET("VnExpress (2025). \"Doanh thu VNPT hơn 58.000 tỷ đồng\". vnexpress.net"),
  BULLET("VNPT (2024). Trang giới thiệu cơ cấu tổ chức. vnpt.com.vn/gioi-thieu/to-chuc/"),
  BULLET("VNPT (2024). \"Phần mềm giải pháp hỗ trợ chăm sóc, tư vấn khách hàng (VNPT Smartbot)\". vnpt.com.vn"),
  BULLET("VNPT AI (2025). Trang sản phẩm VNPT SmartBot. vnptai.io/smartbot/vi"),
  BULLET("VNPT (2024). \"Hướng dẫn đăng ký lắp mạng Internet VNPT - 4 bước\". vnpt.com.vn/tu-van"),
  BULLET("The Open Group (2022). TOGAF Standard, Version 9.2."),
  BULLET("OMG (2014). Business Process Model and Notation (BPMN) Version 2.0.2."),
  BULLET("M. E. Porter (1985). Competitive Advantage: Creating and Sustaining Superior Performance. The Free Press."),
  BULLET("SRM Tech (2024). \"The Role of OSS and BSS in Telecom Management\". srmtech.com"),
  BULLET("Microsoft AI (2024). \"What Are OSS and BSS?\". microsoft.com/en-us/ai/telecommunications"),
];

// ============== BUILD DOC ==============

const doc = new Document({
  creator: "Nguyen Minh Hieu - HV K27",
  title: "Bai Tap Lon HTTTQL - VNPT",
  description: "Bao cao Hoc phan He thong thong tin quan ly nang cao",
  styles: {
    default: {
      document: { run: { font: FONT, size: 26 } }
    },
    paragraphStyles: [
      {
        id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: FONT, color: "1F4E79" },
        paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 }
      },
      {
        id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: FONT, color: "2E75B6" },
        paragraph: { spacing: { before: 240, after: 160 }, outlineLevel: 1 }
      },
      {
        id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, italics: true, font: FONT, color: "404040" },
        paragraph: { spacing: { before: 200, after: 120 }, outlineLevel: 2 }
      }
    ]
  },
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [
          { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } } }
        ]
      }
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 }, // A4
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1800 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: "Bài tập lớn HTTTQL nâng cao - VNPT", italics: true, size: 20, font: FONT, color: "808080" })]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "Trang ", size: 20, font: FONT, color: "808080" }),
            new TextRun({ children: [PageNumber.CURRENT], size: 20, font: FONT, color: "808080" }),
            new TextRun({ text: " / ", size: 20, font: FONT, color: "808080" }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 20, font: FONT, color: "808080" })
          ]
        })]
      })
    },
    children: [
      ...coverPage,
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "MỤC LỤC", bold: true, size: 32, font: FONT })] }),
      new TableOfContents("Mục lục", { hyperlink: true, headingStyleRange: "1-3" }),
      new Paragraph({ children: [new PageBreak()] }),
      ...intro,
      ...cau1,
      ...cau2,
      ...cau3,
      ...cau4,
      ...cau5,
      ...conclusion,
      ...refs
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  const outPath = path.join(__dirname, 'BaiTapLon_HTTTQL_VNPT.docx');
  fs.writeFileSync(outPath, buffer);
  console.log("DONE: " + outPath + " (" + buffer.length + " bytes)");
}).catch(err => {
  console.error("ERROR:", err);
  process.exit(1);
});
